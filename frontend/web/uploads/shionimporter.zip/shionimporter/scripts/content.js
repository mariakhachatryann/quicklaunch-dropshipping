if (window.location.hostname.includes('wholesale7')) {
    window.page_scripts = document.documentElement.cloneNode(true).getElementsByTagName('script');
}