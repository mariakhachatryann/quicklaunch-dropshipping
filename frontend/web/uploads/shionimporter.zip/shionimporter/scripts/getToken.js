const getToken = () => {
  const token = document.querySelector('input#extension_t')?.value;
  window.chrome.storage.sync.set({ token }, () => {});
  window.chrome.storage.sync.get(['returnUrl'], async (result) => {
    const { returnUrl } = result;
    if (returnUrl) {
      window.location.href = returnUrl;
      window.chrome.storage.sync.remove('returnUrl');
    }
  });
};

getToken();
