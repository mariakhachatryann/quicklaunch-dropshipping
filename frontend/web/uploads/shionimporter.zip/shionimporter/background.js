class Background {
  constructor() {
    this.domain = 'https://app.shionimporter.site/api/';
    this.dashboardURL = 'https://app.shionimporter.site/';
    this.dashboardLoginURL = 'https://app.shionimporter.site/login';
    this.listenEvent();
    this.whenChangeUrl();
    this.onInstalled();
  }

  onInstalled() {
    chrome.runtime.onInstalled.addListener(() => {
      chrome.tabs.create({
        url: this.dashboardURL,
      });
    });
  }

  listenEvent() {
    const base = this;
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (typeof base[request.action] !== 'function') {
        sendResponse({ message: 'Invalid Response', status: 0 });
        return false;
      }
      base[request.action](sendResponse, request);
      return true;
    });
  }

  fetchRequest({ url, method, body, token }) {
    const requestParams = {
      method,
      withCredentials: true,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Auth: `Bearer ${token}`,
        ExtensionVersion: '1.1.4'
      },
    };
    if (body) {
      requestParams.body = JSON.stringify(body);
    }
    return fetch(url, requestParams).then((response) =>
      response
        .json()
        .then((json) => (response.ok ? json : Promise.reject(json))),
    );
  }

  fetchResponseText(url, sendResponse) {
    return fetch(url)
      .then((response) => response.text())
      .then((data) => {
        sendResponse(data);
      })
      .catch((err) => {
        console.log(err, 'errr');
      });
  }

  getIndex(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}profile/index`,
      method: 'GET',
      token: request.token,
    })
      .then((data) => {
        sendResponse(data);
      })
      .catch((error) => {
        sendResponse({ status: 0 });
      });
  }

  bulkImport(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}bulk-import/import-items`,
      method: 'POST',
      body: request.data,
      token: request.token,
    })
        .then((data) => {
          sendResponse(data);
        })
        .catch((error) => {
          sendResponse({ status: 0 });
        });
  }

  bulkImportUpdate(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}bulk-import/update-items?id=${request.id}`,
      method: 'GET',
      token: request.token,
    })
        .then((data) => {
          sendResponse(data);
        })
        .catch((error) => {
          sendResponse({ status: 0 });
        });
  }

  publishCategoryProducts(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}bulk-import/publish-products`,
      method: 'POST',
      body: request.data,
      token: request.token,
    })
        .then((data) => {
          sendResponse(data);
        })
        .catch((error) => {
          sendResponse({ status: 0 });
        });
  }

  getCategoryProducts(sendResponse, request) {
    this.fetchRequest({
      url: request.url,
      method: 'GET',
      token: request.token,
    })
        .then((data) => {
          sendResponse(data);
        })
        .catch((error) => {
          sendResponse({ status: 0 });
        });
  }

  getCurrency(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}currency/index`,
      method: 'GET',
      token: request.token,
    })
      .then((data) => {
        sendResponse(data);
      })
      .catch((error) => {
        sendResponse({ status: 0 });
      });
  }

  getRate(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}currency/convert`,
      method: 'POST',
      token: request.token,
      body: {
        from: request.from,
        to: request.to
      },
    })
      .then((data) => {
        sendResponse(data);
      })
      .catch((error) => {
        sendResponse({ status: 0 });
      });
  }

  generateAiContent(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}product/generate-content`,
      method: 'POST',
      token: request.token,
      body: {
        type: request.type,
        url: request.url
      },
    })
      .then((data) => {
        sendResponse(data);
      })
      .catch((error) => {
        sendResponse({ status: 0 });
      });
  }

  getUserProductPricingRules(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}user/product-pricing-rules`,
      method: 'GET',
      token: request.token,
    })
        .then((data) => {
          sendResponse(data);
        })
        .catch((error) => {
          sendResponse({ status: 0 });
        });
  }

  create(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}product/create`,
      method: 'POST',
      token: request.token,
      body: request.data,
    })
      .then((data) => {
        if (data.status === 0) {
          const { errors } = data;
          const errorsArray = Object.keys(errors);
          let responseError = '';
          for (let index = 0; index < errorsArray.length; index += 1) {
            responseError += errors[errorsArray[index]][0];
          }
          sendResponse(responseError);
        } else {
          sendResponse(data);
        }
      })
      .catch((error) => {
        sendResponse(error.message);
      });
  }

  monitorNow(sendResponse, request) {
    console.log(request.data, 'request data')
    this.fetchRequest({
      url: `${this.domain}product/monitor-now`,
      method: 'POST',
      token: request.token,
      body: {data: request.data, id: request.data.monitoring_product_id},
    })
      .then((data) => {
        if (data.status === 0) {
          const { errors } = data;
          const errorsArray = Object.keys(errors);
          let responseError = '';
          for (let index = 0; index < errorsArray.length; index += 1) {
            responseError += errors[errorsArray[index]][0];
          }
          sendResponse(responseError);
        } else {
          sendResponse(data);
        }
      })
  }

  getComments(sendResponse, request) {
    this.fetchRequest({
      url: request.url,
      method: 'GET',
    })
      .then((data) => {
          sendResponse(data);
      })
      .catch((error) => {
        sendResponse(error.message);
      });
  }

  getCommentsText(sendResponse, request) {
    this.fetchResponseText(request.url, sendResponse)
        .then((data) => {
          sendResponse(data)
        })
        .catch((error) => {
          sendResponse(error.message);
        });
  }

  getAmazonVariantHtml(sendResponse, request) {
    const { url } = request;
    this.fetchResponseText(url, sendResponse).then();
  }

  whenChangeUrl() {
    chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
      const { url } = changeInfo;
      if (url) {
        chrome.tabs
          .sendMessage(tabId, {
            url,
          })
          .catch((e) => {
            console.log(e);
          });

        if (url === this.dashboardURL) {
          chrome.scripting.executeScript({
            target: { tabId },
            files: ['./scripts/getToken.js'],
          });
        }
        if (url === this.dashboardLoginURL) {
          chrome.storage.sync.remove('token');
        }
      }
    });
  }

  getDataFromContent(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}product/get-data-from-content`,
      method: 'POST',
      token: request.token,
      body: request.data,
    })
      .then((data) => {
        sendResponse(data);
      })
      .catch((error) => {
        sendResponse({ status: 0 });
      });
  }

  getDetails(sendResponse, request) {
    this.fetchRequest({
      url: request.url,
      method: 'GET',
    })
      .then((data) => {
        sendResponse(data);
      })
      .catch((error) => {
        sendResponse({ status: 0 });
      });
  }

  updateReviews(sendResponse, request) {
    this.fetchRequest({
      url: `${this.domain}product-review/update-reviews`,
      method: `POST`,
      token: request.token,
      body: request.data
    })
        .then((data) => {
          sendResponse(data);
        })
        .catch((error) => {
          sendResponse({ status: 0 });
        });
  }
}


new Background();
